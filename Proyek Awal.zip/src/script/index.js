import Router from '../utils/router.js';

document.addEventListener('DOMContentLoaded', () => {
  console.info('Aplikasi dimuat. Menyiapkan navigasi SPA...');
  Router.mulai();
});
